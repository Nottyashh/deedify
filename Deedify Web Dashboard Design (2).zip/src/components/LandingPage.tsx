import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ArrowRight, Shield, TrendingUp, Users, Coins, Building, CheckCircle } from 'lucide-react';

interface LandingPageProps {
  onPageChange: (page: string) => void;
}

export function LandingPage({ onPageChange }: LandingPageProps) {
  const features = [
    {
      icon: Shield,
      title: 'Secure & Transparent',
      description: 'Blockchain-powered land ownership with smart contracts ensuring security and transparency.'
    },
    {
      icon: TrendingUp,
      title: 'AI-Powered Valuations',
      description: 'Get accurate land valuations using advanced AI algorithms and agricultural market data.'
    },
    {
      icon: Users,
      title: 'Fractional Ownership',
      description: 'Own a fraction of premium agricultural and commercial land starting from just $100.'
    },
    {
      icon: Coins,
      title: 'Instant Liquidity',
      description: 'Trade your land fractions anytime on our secondary NFT marketplace.'
    }
  ];

  const stats = [
    { label: 'Land Parcels Listed', value: '2,847' },
    { label: 'Total Invested', value: '$45.2M' },
    { label: 'Active Investors', value: '12,458' },
    { label: 'Avg. Returns', value: '14.2%' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <div className="inline-flex items-center px-4 py-2 bg-primary/10 rounded-full text-primary text-sm">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Blockchain-Powered Land Investment
                </div>
                <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  Own Land,{' '}
                  <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                    One Fraction at a Time
                  </span>
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed">
                  Invest in premium agricultural and commercial land parcels with as little as $100. 
                  Get instant ownership certificates as NFTs and earn from land appreciation.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-primary hover:bg-primary/90 text-lg px-8 py-4"
                  onClick={() => onPageChange('properties')}
                >
                  Browse Land Parcels
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="text-lg px-8 py-4 border-gray-300"
                  onClick={() => onPageChange('auth')}
                >
                  Get Started
                </Button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 pt-8">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                    <div className="text-sm text-gray-600">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="relative bg-gradient-to-br from-primary/20 to-secondary/20 rounded-3xl p-8">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1586859821397-c81e4971ca82?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtbGFuZCUyMGFncmljdWx0dXJhbCUyMHBsb3R8ZW58MXx8fHwxNzU4MDMyOTc5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Agricultural farmland"
                  className="w-full h-96 object-cover rounded-2xl shadow-2xl"
                />
                
                {/* Floating NFT Card */}
                <div className="absolute -bottom-4 -right-4 bg-white rounded-xl shadow-lg p-4 border">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
                      <Building className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">NFT #1247</div>
                      <div className="text-sm text-gray-600">0.05 ETH</div>
                    </div>
                  </div>
                </div>

                {/* Blockchain Icons */}
                <div className="absolute -top-4 -left-4 w-8 h-8 bg-secondary/20 rounded-lg flex items-center justify-center">
                  <div className="w-3 h-3 bg-secondary rounded-full"></div>
                </div>
                <div className="absolute top-8 -right-2 w-6 h-6 bg-primary/20 rounded-md flex items-center justify-center">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold text-gray-900">
              Why Choose Deedify?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Experience the future of land investment with our innovative blockchain platform
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                  <CardContent className="p-6 text-center space-y-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mx-auto">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900">{feature.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary to-secondary">
        <div className="max-w-4xl mx-auto text-center px-6 space-y-8">
          <h2 className="text-4xl font-bold text-white">
            Ready to Start Your Land Investment Journey?
          </h2>
          <p className="text-xl text-white/90">
            Join thousands of investors who are already building wealth through fractional land ownership
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              variant="secondary"
              className="bg-white text-primary hover:bg-gray-100 text-lg px-8 py-4"
              onClick={() => onPageChange('auth')}
            >
              Start Investing Today
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white/10 text-lg px-8 py-4"
              onClick={() => onPageChange('properties')}
            >
              Browse Land Parcels
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}