import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardFooter } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { MapPin, TrendingUp, Star, Filter, Search } from 'lucide-react';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface Property {
  id: string;
  title: string;
  location: string;
  image: string;
  pricePerFraction: number;
  totalValue: number;
  aiValuation: {
    low: number;
    mid: number;
    high: number;
  };
  fractionsAvailable: number;
  totalFractions: number;
  expectedReturn: number;
  propertyType: string;
  featured: boolean;
}

interface PropertyListingsProps {
  onPropertySelect: (propertyId: string) => void;
}

export function PropertyListings({ onPropertySelect }: PropertyListingsProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [sortBy, setSortBy] = useState('featured');

  const properties: Property[] = [
    {
      id: '1',
      title: 'Agricultural Plot A-17, Maharashtra',
      location: 'Nashik District, Maharashtra',
      image: 'https://images.unsplash.com/photo-1586859821397-c81e4971ca82?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtbGFuZCUyMGFncmljdWx0dXJhbCUyMHBsb3R8ZW58MXx8fHwxNzU4MDMyOTc5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      pricePerFraction: 1250,
      totalValue: 5000000,
      aiValuation: { low: 4800000, mid: 5200000, high: 5600000 },
      fractionsAvailable: 1200,
      totalFractions: 4000,
      expectedReturn: 14.2,
      propertyType: 'Agricultural',
      featured: true
    },
    {
      id: '2',
      title: 'Commercial Land Parcel',
      location: 'Gurgaon, Haryana',
      image: 'https://images.unsplash.com/photo-1515102502805-e970df437805?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZ3JpY3VsdHVyYWwlMjBsYW5kJTIwcGxvdCUyMGFlcmlhbHxlbnwxfHx8fDE3NTgwMzI5ODJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      pricePerFraction: 875,
      totalValue: 3500000,
      aiValuation: { low: 3200000, mid: 3500000, high: 3800000 },
      fractionsAvailable: 800,
      totalFractions: 4000,
      expectedReturn: 12.8,
      propertyType: 'Commercial',
      featured: true
    },
    {
      id: '3',
      title: 'Prime Agricultural Land',
      location: 'Punjab, India',
      image: 'https://images.unsplash.com/photo-1671699556172-d9d39527dae5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtJTIwZmllbGQlMjBncmVlbiUyMGxhbmR8ZW58MXx8fHwxNzU4MDMyOTg0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      pricePerFraction: 2100,
      totalValue: 8400000,
      aiValuation: { low: 8000000, mid: 8400000, high: 9200000 },
      fractionsAvailable: 600,
      totalFractions: 4000,
      expectedReturn: 16.5,
      propertyType: 'Agricultural',
      featured: false
    },
    {
      id: '4',
      title: 'Organic Farm Plot B-23',
      location: 'Karnataka, India',
      image: 'https://images.unsplash.com/photo-1586859821397-c81e4971ca82?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtbGFuZCUyMGFncmljdWx0dXJhbCUyMHBsb3R8ZW58MXx8fHwxNzU4MDMyOTc5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      pricePerFraction: 1875,
      totalValue: 7500000,
      aiValuation: { low: 7200000, mid: 7500000, high: 7900000 },
      fractionsAvailable: 320,
      totalFractions: 4000,
      expectedReturn: 13.7,
      propertyType: 'Agricultural',
      featured: false
    },
    {
      id: '5',
      title: 'Industrial Land Zone',
      location: 'Hyderabad, Telangana',
      image: 'https://images.unsplash.com/photo-1515102502805-e970df437805?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZ3JpY3VsdHVyYWwlMjBsYW5kJTIwcGxvdCUyMGFlcmlhbHxlbnwxfHx8fDE3NTgwMzI5ODJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      pricePerFraction: 1500,
      totalValue: 6000000,
      aiValuation: { low: 5800000, mid: 6000000, high: 6400000 },
      fractionsAvailable: 950,
      totalFractions: 4000,
      expectedReturn: 15.1,
      propertyType: 'Commercial',
      featured: true
    },
    {
      id: '6',
      title: 'Coastal Agricultural Plot',
      location: 'Konkan Coast, Maharashtra',
      image: 'https://images.unsplash.com/photo-1671699556172-d9d39527dae5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtJTIwZmllbGQlMjBncmVlbiUyMGxhbmR8ZW58MXx8fHwxNzU4MDMyOTg0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      pricePerFraction: 3200,
      totalValue: 12800000,
      aiValuation: { low: 12000000, mid: 12800000, high: 13500000 },
      fractionsAvailable: 450,
      totalFractions: 4000,
      expectedReturn: 11.9,
      propertyType: 'Agricultural',
      featured: false
    }
  ];

  const filteredProperties = properties.filter(property => {
    const matchesSearch = property.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         property.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || property.propertyType.toLowerCase() === filterType;
    return matchesSearch && matchesType;
  });

  const sortedProperties = [...filteredProperties].sort((a, b) => {
    switch (sortBy) {
      case 'featured':
        return b.featured ? 1 : -1;
      case 'price-low':
        return a.pricePerFraction - b.pricePerFraction;
      case 'price-high':
        return b.pricePerFraction - a.pricePerFraction;
      case 'return':
        return b.expectedReturn - a.expectedReturn;
      default:
        return 0;
    }
  });

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Land Parcel Listings</h1>
          <p className="text-gray-600">Discover premium agricultural and commercial land investment opportunities</p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search land parcels..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger>
                <SelectValue placeholder="Land Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="agricultural">Agricultural</SelectItem>
                <SelectItem value="commercial">Commercial</SelectItem>
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger>
                <SelectValue placeholder="Sort By" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="featured">Featured</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="return">Expected Return</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" className="flex items-center space-x-2">
              <Filter className="w-4 h-4" />
              <span>More Filters</span>
            </Button>
          </div>
        </div>

        {/* Property Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedProperties.map((property) => (
            <Card key={property.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer" onClick={() => onPropertySelect(property.id)}>
              <div className="relative">
                <ImageWithFallback
                  src={property.image}
                  alt={property.title}
                  className="w-full h-48 object-cover"
                />
                {property.featured && (
                  <Badge className="absolute top-3 left-3 bg-primary text-white">
                    <Star className="w-3 h-3 mr-1" />
                    Featured
                  </Badge>
                )}
                <Badge 
                  variant="secondary" 
                  className="absolute top-3 right-3 bg-white/90 text-gray-900"
                >
                  {property.propertyType}
                </Badge>
              </div>

              <CardContent className="p-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{property.title}</h3>
                    <div className="flex items-center text-gray-600 text-sm">
                      <MapPin className="w-4 h-4 mr-1" />
                      {property.location}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">AI Valuation Range</span>
                      <TrendingUp className="w-4 h-4 text-green-500" />
                    </div>
                    <div className="text-sm text-gray-700">
                      ₹{(property.aiValuation.low / 100000).toFixed(1)}L - ₹{(property.aiValuation.high / 100000).toFixed(1)}L
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-gray-600">Price per Fraction</div>
                      <div className="font-semibold">₹{property.pricePerFraction.toLocaleString()}</div>
                    </div>
                    <div>
                      <div className="text-gray-600">Expected Return</div>
                      <div className="font-semibold text-green-600">{property.expectedReturn}%</div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Available Fractions</span>
                      <span>{property.fractionsAvailable}/{property.totalFractions}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-primary h-2 rounded-full" 
                        style={{ width: `${((property.totalFractions - property.fractionsAvailable) / property.totalFractions) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </CardContent>

              <CardFooter className="p-6 pt-0">
                <Button className="w-full bg-primary hover:bg-primary/90">
                  Invest Now
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <Button variant="outline" className="px-8">
            Load More Land Parcels
          </Button>
        </div>
      </div>
    </div>
  );
}