import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  MapPin, 
  Search, 
  Filter, 
  DollarSign, 
  Wallet, 
  Tag,
  TrendingUp,
  Clock,
  User,
  Gavel,
  X
} from 'lucide-react';

interface LandListing {
  id: string;
  propertyTitle: string;
  propertyLocation: string;
  propertyImage: string;
  tokenId: string;
  fractionsOwned: number;
  totalFractions: number;
  currentOwner: string;
  ownerAddress: string;
  askingPrice: number;
  pricePerFraction: number;
  originalPrice: number;
  listedDate: string;
  propertyType: string;
  isActive: boolean;
}

interface NFTMarketplaceProps {
  userAddress?: string;
}

export function NFTMarketplace({ userAddress = '0x1234...5678' }: NFTMarketplaceProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  const [selectedListing, setSelectedListing] = useState<LandListing | null>(null);
  const [listingPrice, setListingPrice] = useState('');
  const [showListDialog, setShowListDialog] = useState(false);

  const landListings: LandListing[] = [
    {
      id: '1',
      propertyTitle: '2-Acre Farmland, Pune',
      propertyLocation: 'Pune District, Maharashtra',
      propertyImage: 'https://images.unsplash.com/photo-1586859821397-c81e4971ca82?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtbGFuZCUyMGFncmljdWx0dXJhbCUyMHBsb3R8ZW58MXx8fHwxNzU4MDMyOTc5fDA&ixlib=rb-4.1.0&q=80&w=1080',
      tokenId: 'LAND-001247',
      fractionsOwned: 25,
      totalFractions: 4000,
      currentOwner: 'Rajesh Kumar',
      ownerAddress: '0xabc123...def456',
      askingPrice: 32500,
      pricePerFraction: 1300,
      originalPrice: 1250,
      listedDate: '2024-01-15',
      propertyType: 'Agricultural',
      isActive: true
    },
    {
      id: '2',
      propertyTitle: 'Commercial Plot B-45',
      propertyLocation: 'Gurgaon, Haryana',
      propertyImage: 'https://images.unsplash.com/photo-1515102502805-e970df437805?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZ3JpY3VsdHVyYWwlMjBsYW5kJTIwcGxvdCUyMGFlcmlhbHxlbnwxfHx8fDE3NTgwMzI5ODJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      tokenId: 'LAND-001156',
      fractionsOwned: 50,
      totalFractions: 4000,
      currentOwner: 'Priya Sharma',
      ownerAddress: '0x789xyz...abc123',
      askingPrice: 45000,
      pricePerFraction: 900,
      originalPrice: 875,
      listedDate: '2024-01-12',
      propertyType: 'Commercial',
      isActive: true
    },
    {
      id: '3',
      propertyTitle: '5-Acre Agricultural Land',
      propertyLocation: 'Ludhiana, Punjab',
      propertyImage: 'https://images.unsplash.com/photo-1671699556172-d9d39527dae5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtJTIwZmllbGQlMjBncmVlbiUyMGxhbmR8ZW58MXx8fHwxNzU4MDMyOTg0fDA&ixlib=rb-4.1.0&q=80&w=1080',
      tokenId: 'LAND-001089',
      fractionsOwned: 15,
      totalFractions: 4000,
      currentOwner: 'Amit Patel',
      ownerAddress: '0x456def...789ghi',
      askingPrice: 33000,
      pricePerFraction: 2200,
      originalPrice: 2100,
      listedDate: '2024-01-10',
      propertyType: 'Agricultural',
      isActive: true
    },
    {
      id: '4',
      propertyTitle: 'Coastal Organic Farm Plot',
      propertyLocation: 'Konkan Coast, Maharashtra',
      propertyImage: 'https://images.unsplash.com/photo-1586859821397-c81e4971ca82?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtbGFuZCUyMGFncmljdWx0dXJhbCUyMHBsb3R8ZW58MXx8fHwxNzU4MDMyOTc5fDA&ixlib=rb-4.1.0&q=80&w=1080',
      tokenId: 'LAND-000892',
      fractionsOwned: 8,
      totalFractions: 4000,
      currentOwner: 'Sneha Reddy',
      ownerAddress: '0x123abc...456def',
      askingPrice: 26400,
      pricePerFraction: 3300,
      originalPrice: 3200,
      listedDate: '2024-01-08',
      propertyType: 'Agricultural',
      isActive: true
    }
  ];

  const filteredListings = landListings.filter(listing => {
    const matchesSearch = listing.propertyTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         listing.propertyLocation.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || listing.propertyType.toLowerCase() === filterType;
    return matchesSearch && matchesType && listing.isActive;
  });

  const sortedListings = [...filteredListings].sort((a, b) => {
    switch (sortBy) {
      case 'newest':
        return new Date(b.listedDate).getTime() - new Date(a.listedDate).getTime();
      case 'price-low':
        return a.pricePerFraction - b.pricePerFraction;
      case 'price-high':
        return b.pricePerFraction - a.pricePerFraction;
      case 'fractions':
        return b.fractionsOwned - a.fractionsOwned;
      default:
        return 0;
    }
  });

  const handleBuyNow = (listing: LandListing) => {
    setSelectedListing(listing);
    // In real app, this would open buy modal/flow
    alert(`Buying ${listing.fractionsOwned} fractions of ${listing.propertyTitle} land parcel for ₹${listing.askingPrice.toLocaleString()}`);
  };

  const handleListForSale = () => {
    setShowListDialog(true);
  };

  const handleConfirmListing = () => {
    if (listingPrice) {
      alert(`Listed your land fractions for sale at ₹${listingPrice} per fraction`);
      setShowListDialog(false);
      setListingPrice('');
    }
  };

  const calculatePriceChange = (current: number, original: number) => {
    const change = ((current - original) / original) * 100;
    return change;
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Land Parcel Marketplace</h1>
              <p className="text-gray-600">Trade fractional ownership of land parcels securely on-chain</p>
            </div>
            <Button 
              onClick={handleListForSale}
              className="bg-primary hover:bg-primary/90 flex items-center space-x-2"
            >
              <Tag className="w-4 h-4" />
              <span>List Land Fractions</span>
            </Button>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search land parcels..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger>
                <SelectValue placeholder="Land Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="agricultural">Agricultural</SelectItem>
                <SelectItem value="commercial">Commercial</SelectItem>
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger>
                <SelectValue placeholder="Sort By" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest Listed</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="fractions">Most Fractions</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" className="flex items-center space-x-2">
              <Filter className="w-4 h-4" />
              <span>More Filters</span>
            </Button>
          </div>
        </div>

        {/* Land Parcel Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedListings.map((listing) => {
            const priceChange = calculatePriceChange(listing.pricePerFraction, listing.originalPrice);
            return (
              <Card key={listing.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative">
                  <ImageWithFallback
                    src={listing.propertyImage}
                    alt={listing.propertyTitle}
                    className="w-full h-48 object-cover"
                  />
                  <Badge 
                    variant="secondary" 
                    className="absolute top-3 left-3 bg-white/90 text-gray-900"
                  >
                    {listing.propertyType}
                  </Badge>
                  <Badge 
                    className="absolute top-3 right-3 bg-purple-500 text-white"
                  >
                    Land #{listing.tokenId.split('-')[1]}
                  </Badge>
                </div>

                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{listing.propertyTitle}</h3>
                      <div className="flex items-center text-gray-600 text-sm">
                        <MapPin className="w-4 h-4 mr-1" />
                        {listing.propertyLocation}
                      </div>
                    </div>

                    <div className="flex items-center space-x-2 text-sm">
                      <User className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-600">Owner:</span>
                      <span className="font-medium">{listing.currentOwner}</span>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="text-gray-600">Fractions</div>
                        <div className="font-semibold">{listing.fractionsOwned}</div>
                      </div>
                      <div>
                        <div className="text-gray-600">Listed</div>
                        <div className="font-semibold flex items-center">
                          <Clock className="w-3 h-3 mr-1" />
                          {new Date(listing.listedDate).toLocaleDateString()}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Price per Fraction</span>
                        <div className="flex items-center space-x-2">
                          <span className={`text-sm ${priceChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {priceChange >= 0 ? '+' : ''}{priceChange.toFixed(1)}%
                          </span>
                          <TrendingUp className={`w-3 h-3 ${priceChange >= 0 ? 'text-green-600' : 'text-red-600'}`} />
                        </div>
                      </div>
                      <div className="text-2xl font-bold text-gray-900">
                        ₹{listing.pricePerFraction.toLocaleString()}
                      </div>
                      <div className="text-sm text-gray-500">
                        Total: ₹{listing.askingPrice.toLocaleString()}
                      </div>
                    </div>
                  </div>
                </CardContent>

                <CardFooter className="p-6 pt-0 space-y-3">
                  <Button 
                    onClick={() => handleBuyNow(listing)}
                    className="w-full bg-primary hover:bg-primary/90 flex items-center justify-center space-x-2"
                  >
                    <Gavel className="w-4 h-4" />
                    <span>Buy Now</span>
                  </Button>
                  <div className="grid grid-cols-2 gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="flex items-center justify-center space-x-1"
                    >
                      <Wallet className="w-3 h-3" />
                      <span>USDC</span>
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="flex items-center justify-center space-x-1"
                    >
                      <DollarSign className="w-3 h-3" />
                      <span>INR</span>
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            );
          })}
        </div>

        {/* List Land Fractions Dialog */}
        <Dialog open={showListDialog} onOpenChange={setShowListDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>List Your Land Fractions for Sale</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="property-select">Select Land Parcel</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose your land parcel" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="land-001">2-Acre Farmland, Pune (15 fractions)</SelectItem>
                      <SelectItem value="land-002">Commercial Plot B-45 (8 fractions)</SelectItem>
                      <SelectItem value="land-003">5-Acre Agricultural Land (22 fractions)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="listing-price">Price per Fraction (₹)</Label>
                  <Input
                    id="listing-price"
                    type="number"
                    placeholder="Enter price per fraction"
                    value={listingPrice}
                    onChange={(e) => setListingPrice(e.target.value)}
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    Current market price: ₹1,250
                  </p>
                </div>

                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-medium text-gray-900 mb-2">Listing Summary</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Fractions to sell:</span>
                      <span className="font-medium">15</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Price per fraction:</span>
                      <span className="font-medium">₹{listingPrice || '0'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total value:</span>
                      <span className="font-medium">₹{(parseInt(listingPrice || '0') * 15).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-gray-600">
                      <span>Platform fee (2.5%):</span>
                      <span>₹{((parseInt(listingPrice || '0') * 15 * 0.025)).toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex space-x-3">
                <Button 
                  variant="outline" 
                  onClick={() => setShowListDialog(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleConfirmListing}
                  className="flex-1 bg-primary hover:bg-primary/90"
                  disabled={!listingPrice}
                >
                  List for Sale
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Load More */}
        <div className="text-center mt-12">
          <Button variant="outline" className="px-8">
            Load More Land Parcels
          </Button>
        </div>
      </div>
    </div>
  );
}