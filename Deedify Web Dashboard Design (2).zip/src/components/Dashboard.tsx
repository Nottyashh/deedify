import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Button } from './ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Progress } from './ui/progress';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, DollarSign, Building2, Wallet, Download, Eye, ArrowUpRight, ArrowDownRight, Vote, CheckCircle, Clock, Users } from 'lucide-react';

interface DashboardProps {
  userHoldings?: { [propertyId: string]: number };
}

export function Dashboard({ userHoldings = {} }: DashboardProps) {
  const [selectedPeriod, setSelectedPeriod] = useState('6M');

  // Mock user data
  const userStats = {
    totalValue: 245000,
    totalInvested: 180000,
    totalReturn: 65000,
    totalLandParcels: 8,
    monthlyIncome: 3250,
    returnPercentage: 36.1
  };

  const holdings = [
    {
      id: '1',
      name: 'Agricultural Plot A-17',
      location: 'Nashik District, Maharashtra',
      tokenId: 'DFY-001247',
      fractions: userHoldings['1'] || 0,
      currentValue: (userHoldings['1'] || 0) * 1250,
      invested: (userHoldings['1'] || 0) * 1250,
      return: 25.0,
      image: 'https://images.unsplash.com/photo-1586859821397-c81e4971ca82?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtbGFuZCUyMGFncmljdWx0dXJhbCUyMHBsb3R8ZW58MXx8fHwxNzU4MDMyOTc5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      id: '2',
      name: 'Commercial Land Parcel',
      location: 'Gurgaon, Haryana',
      tokenId: 'DFY-002156',
      fractions: userHoldings['2'] || 0,
      currentValue: (userHoldings['2'] || 0) * 875,
      invested: (userHoldings['2'] || 0) * 875,
      return: 20.0,
      image: 'https://images.unsplash.com/photo-1515102502805-e970df437805?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZ3JpY3VsdHVyYWwlMjBsYW5kJTIwcGxvdCUyMGFlcmlhbHxlbnwxfHx8fDE3NTgwMzI5ODJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      id: '3',
      name: 'Prime Agricultural Land',
      location: 'Punjab, India',
      tokenId: 'DFY-003891',
      fractions: userHoldings['3'] || 0,
      currentValue: (userHoldings['3'] || 0) * 2100,
      invested: (userHoldings['3'] || 0) * 2100,
      return: 25.0,
      image: 'https://images.unsplash.com/photo-1671699556172-d9d39527dae5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtJTIwZmllbGQlMjBncmVlbiUyMGxhbmR8ZW58MXx8fHwxNzU4MDMyOTg0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    }
  ].filter(holding => holding.fractions > 0); // Only show holdings where user has fractions

  const transactions = [
    { id: '1', type: 'Purchase', property: 'Agricultural Plot A-17', amount: 15000, date: '2024-01-15', status: 'Completed' },
    { id: '2', type: 'Land Lease Income', property: 'Commercial Land Parcel', amount: 350, date: '2024-01-01', status: 'Received' },
    { id: '3', type: 'Purchase', property: 'Prime Agricultural Land', amount: 25200, date: '2023-12-20', status: 'Completed' },
    { id: '4', type: 'Land Lease Income', property: 'Agricultural Plot A-17', amount: 425, date: '2023-12-01', status: 'Received' },
    { id: '5', type: 'Sale', property: 'Industrial Land Zone', amount: 12800, date: '2023-11-15', status: 'Completed' }
  ];

  const portfolioData = [
    { month: 'Jul', value: 125000 },
    { month: 'Aug', value: 142000 },
    { month: 'Sep', value: 158000 },
    { month: 'Oct', value: 175000 },
    { month: 'Nov', value: 198000 },
    { month: 'Dec', value: 215000 },
    { month: 'Jan', value: 245000 }
  ];

  const incomeData = [
    { month: 'Jul', income: 2100 },
    { month: 'Aug', income: 2350 },
    { month: 'Sep', income: 2580 },
    { month: 'Oct', income: 2750 },
    { month: 'Nov', income: 2950 },
    { month: 'Dec', income: 3150 },
    { month: 'Jan', income: 3250 }
  ];

  const assetAllocation = [
    { name: 'Agricultural', value: 55, color: '#27AE60' },
    { name: 'Commercial', value: 35, color: '#2F80ED' },
    { name: 'Industrial', value: 10, color: '#9B59B6' }
  ];

  // Mock voting proposals data
  const votingProposals = [
    {
      id: '1',
      title: 'Upgrade Irrigation System - Agricultural Plot A-17',
      description: 'Proposal to install a modern drip irrigation system to increase crop yield by 30% and reduce water consumption.',
      propertyId: '1',
      propertyName: 'Agricultural Plot A-17',
      type: 'Infrastructure',
      status: 'active',
      totalVotes: 2847,
      votesFor: 1892,
      votesAgainst: 955,
      userVotingPower: userHoldings['1'] || 0,
      totalFractions: 4000,
      deadline: '2024-02-15',
      daysLeft: 8,
      userVoted: false,
      estimatedCost: '₹12,50,000',
      expectedROI: '25% increase in rental yield'
    },
    {
      id: '2',
      title: 'Land Development Approval - Commercial Land Parcel',
      description: 'Vote on whether to proceed with commercial development of the Gurgaon land parcel for retail complex.',
      propertyId: '2',
      propertyName: 'Commercial Land Parcel',
      type: 'Development',
      status: 'active',
      totalVotes: 3156,
      votesFor: 2234,
      votesAgainst: 922,
      userVotingPower: userHoldings['2'] || 0,
      totalFractions: 4000,
      deadline: '2024-02-20',
      daysLeft: 13,
      userVoted: true,
      userVote: 'for',
      estimatedCost: '₹45,00,000',
      expectedROI: '40% increase in land value'
    },
    {
      id: '3',
      title: 'Organic Certification - Prime Agricultural Land',
      description: 'Proposal to obtain organic certification for the Punjab agricultural land to access premium markets.',
      propertyId: '3',
      propertyName: 'Prime Agricultural Land',
      type: 'Certification',
      status: 'ended',
      result: 'passed',
      totalVotes: 3891,
      votesFor: 2567,
      votesAgainst: 1324,
      userVotingPower: userHoldings['3'] || 0,
      totalFractions: 4000,
      deadline: '2024-01-30',
      daysLeft: 0,
      userVoted: true,
      userVote: 'for',
      estimatedCost: '₹3,50,000',
      expectedROI: '15% premium on crop prices'
    }
  ].filter(proposal => proposal.userVotingPower > 0); // Only show proposals for properties where user has voting power

  const totalVotingPower = holdings.reduce((sum, holding) => sum + holding.fractions, 0);

  const handleVote = (proposalId: string, vote: 'for' | 'against') => {
    // Mock voting logic
    alert(`You voted ${vote} on proposal ${proposalId}`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Land Investment Dashboard</h1>
              <p className="text-gray-600 mt-1">Track your land portfolio performance</p>
            </div>
            <div className="flex space-x-3">
              <Button variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Export Report
              </Button>
              <Button className="bg-primary hover:bg-primary/90">
                Add Investment
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Portfolio Value</p>
                  <p className="text-2xl font-bold text-gray-900">₹{userStats.totalValue.toLocaleString()}</p>
                  <div className="flex items-center mt-1">
                    <ArrowUpRight className="w-4 h-4 text-green-500 mr-1" />
                    <span className="text-sm text-green-500">+{userStats.returnPercentage}%</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Invested</p>
                  <p className="text-2xl font-bold text-gray-900">₹{userStats.totalInvested.toLocaleString()}</p>
                  <p className="text-sm text-gray-600 mt-1">Across {userStats.totalProperties} properties</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Returns</p>
                  <p className="text-2xl font-bold text-gray-900">₹{userStats.totalReturn.toLocaleString()}</p>
                  <div className="flex items-center mt-1">
                    <ArrowUpRight className="w-4 h-4 text-green-500 mr-1" />
                    <span className="text-sm text-green-500">36.1% gain</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Monthly Income</p>
                  <p className="text-2xl font-bold text-gray-900">₹{userStats.monthlyIncome.toLocaleString()}</p>
                  <p className="text-sm text-gray-600 mt-1">From rental income</p>
                </div>
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <Wallet className="w-6 h-6 text-yellow-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="holdings" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="holdings">My Holdings</TabsTrigger>
            <TabsTrigger value="voting">Voting</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="holdings" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Holdings Table */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Land Holdings</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Land Parcel</TableHead>
                          <TableHead>Token ID</TableHead>
                          <TableHead>Fractions</TableHead>
                          <TableHead>Current Value</TableHead>
                          <TableHead>Return</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {holdings.map((holding) => (
                          <TableRow key={holding.id}>
                            <TableCell>
                              <div className="flex items-center space-x-3">
                                <ImageWithFallback
                                  src={holding.image}
                                  alt={holding.name}
                                  className="w-12 h-12 rounded-lg object-cover"
                                />
                                <div>
                                  <div className="font-medium">{holding.name}</div>
                                  <div className="text-sm text-gray-600">{holding.location}</div>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <code className="text-xs bg-gray-100 px-2 py-1 rounded">{holding.tokenId}</code>
                            </TableCell>
                            <TableCell>{holding.fractions}</TableCell>
                            <TableCell>₹{holding.currentValue.toLocaleString()}</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="bg-green-100 text-green-800">
                                +{holding.return}%
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button variant="outline" size="sm">
                                  <Eye className="w-4 h-4" />
                                </Button>
                                <Button variant="outline" size="sm">
                                  Trade
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </div>

              {/* Asset Allocation */}
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>Asset Allocation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64 mb-4">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={assetAllocation}
                            cx="50%"
                            cy="50%"
                            innerRadius={40}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                          >
                            {assetAllocation.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    
                    <div className="space-y-2">
                      {assetAllocation.map((item, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <div 
                              className="w-3 h-3 rounded-full" 
                              style={{ backgroundColor: item.color }}
                            ></div>
                            <span className="text-sm">{item.name}</span>
                          </div>
                          <span className="text-sm font-medium">{item.value}%</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="voting" className="space-y-6">
            {/* Voting Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Total Voting Power</p>
                      <p className="text-2xl font-bold text-gray-900">{totalVotingPower}</p>
                      <p className="text-sm text-gray-600 mt-1">Across {holdings.length} properties</p>
                    </div>
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Vote className="w-6 h-6 text-blue-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Active Proposals</p>
                      <p className="text-2xl font-bold text-gray-900">{votingProposals.filter(p => p.status === 'active').length}</p>
                      <p className="text-sm text-gray-600 mt-1">Requiring your vote</p>
                    </div>
                    <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                      <Clock className="w-6 h-6 text-orange-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Voted This Month</p>
                      <p className="text-2xl font-bold text-gray-900">{votingProposals.filter(p => p.userVoted).length}</p>
                      <p className="text-sm text-gray-600 mt-1">Out of {votingProposals.length} proposals</p>
                    </div>
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Voting Proposals */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Governance Proposals</h3>
              {votingProposals.length === 0 ? (
                <Card>
                  <CardContent className="p-8 text-center">
                    <Vote className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">No Voting Rights Yet</h4>
                    <p className="text-gray-600 mb-4">
                      Purchase land fractions to participate in governance decisions and earn voting rights.
                    </p>
                    <Button 
                      className="bg-primary hover:bg-primary/90"
                      onClick={() => window.location.reload()} // Redirect to properties would be better
                    >
                      Browse Land Parcels
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                votingProposals.map((proposal) => (
                  <Card key={proposal.id}>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        {/* Proposal Header */}
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <h4 className="font-semibold text-lg">{proposal.title}</h4>
                              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                {proposal.type}
                              </Badge>
                              <Badge 
                                variant={proposal.status === 'active' ? 'default' : 
                                       proposal.status === 'ended' ? 'secondary' : 'outline'}
                                className={proposal.status === 'active' ? 'bg-green-100 text-green-800 border-green-200' : ''}
                              >
                                {proposal.status === 'active' ? `${proposal.daysLeft} days left` : proposal.status}
                              </Badge>
                            </div>
                            <p className="text-gray-600 mb-3">{proposal.description}</p>
                            <div className="flex items-center space-x-4 text-sm text-gray-600">
                              <span>Property: {proposal.propertyName}</span>
                              <span>Cost: {proposal.estimatedCost}</span>
                              <span>Expected ROI: {proposal.expectedROI}</span>
                            </div>
                          </div>
                        </div>

                        {/* Voting Results */}
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Votes For ({proposal.votesFor})</span>
                            <span className="text-sm text-gray-600">
                              {((proposal.votesFor / proposal.totalVotes) * 100).toFixed(1)}%
                            </span>
                          </div>
                          <Progress 
                            value={(proposal.votesFor / proposal.totalVotes) * 100} 
                            className="h-2" 
                          />
                          
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Votes Against ({proposal.votesAgainst})</span>
                            <span className="text-sm text-gray-600">
                              {((proposal.votesAgainst / proposal.totalVotes) * 100).toFixed(1)}%
                            </span>
                          </div>
                          <Progress 
                            value={(proposal.votesAgainst / proposal.totalVotes) * 100} 
                            className="h-2" 
                          />
                        </div>

                        {/* Voting Power & Actions */}
                        <div className="flex justify-between items-center pt-4 border-t">
                          <div className="flex items-center space-x-4">
                            <span className="text-sm text-gray-600">
                              Your voting power: <span className="font-semibold">{proposal.userVotingPower} fractions</span>
                            </span>
                            <span className="text-sm text-gray-600">
                              ({((proposal.userVotingPower / proposal.totalFractions) * 100).toFixed(2)}% of total)
                            </span>
                          </div>
                          
                          <div className="flex space-x-2">
                            {proposal.userVoted ? (
                              <div className="flex items-center space-x-2">
                                <CheckCircle className="w-4 h-4 text-green-500" />
                                <span className="text-sm text-green-600">
                                  You voted {proposal.userVote}
                                </span>
                              </div>
                            ) : proposal.status === 'active' ? (
                              <>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleVote(proposal.id, 'for')}
                                  className="text-green-600 border-green-200 hover:bg-green-50"
                                >
                                  <Vote className="w-4 h-4 mr-1" />
                                  Vote For
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleVote(proposal.id, 'against')}
                                  className="text-red-600 border-red-200 hover:bg-red-50"
                                >
                                  <Vote className="w-4 h-4 mr-1" />
                                  Vote Against
                                </Button>
                              </>
                            ) : (
                              <Badge variant="secondary">
                                {proposal.result === 'passed' ? 'Proposal Passed' : 'Voting Ended'}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="transactions" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Transaction History</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Type</TableHead>
                      <TableHead>Land Parcel</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell>
                          <Badge 
                            variant={transaction.type === 'Purchase' ? 'destructive' : 
                                   transaction.type === 'Sale' ? 'secondary' : 'default'}
                          >
                            {transaction.type}
                          </Badge>
                        </TableCell>
                        <TableCell>{transaction.property}</TableCell>
                        <TableCell>
                          <span className={transaction.type === 'Purchase' ? 'text-red-600' : 'text-green-600'}>
                            {transaction.type === 'Purchase' ? '-' : '+'}₹{transaction.amount.toLocaleString()}
                          </span>
                        </TableCell>
                        <TableCell>{transaction.date}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-green-600 border-green-200">
                            {transaction.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button variant="outline" size="sm">
                            <Download className="w-4 h-4 mr-1" />
                            Receipt
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Portfolio Value Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Portfolio Value Over Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={portfolioData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip formatter={(value) => [`₹${value.toLocaleString()}`, 'Portfolio Value']} />
                        <Line 
                          type="monotone" 
                          dataKey="value" 
                          stroke="#27AE60" 
                          strokeWidth={3}
                          dot={{ fill: '#27AE60', strokeWidth: 2, r: 4 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Monthly Income Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Monthly Rental Income</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={incomeData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip formatter={(value) => [`₹${value.toLocaleString()}`, 'Income']} />
                        <Bar dataKey="income" fill="#2F80ED" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}