import React from 'react';
import { Button } from './ui/button';
import { Avatar, AvatarFallback } from './ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from './ui/dropdown-menu';
import { Building2, Wallet, BarChart3, Settings, Home, ShoppingCart, User, LogOut, CreditCard } from 'lucide-react';
import deedifyLogo from 'figma:asset/55cb4fe518147b5b4d46a2dab11129d320de14d0.png';

interface NavigationProps {
  currentPage: string;
  onPageChange: (page: string) => void;
  isAuthenticated?: boolean;
  userWallet?: string | null;
  onLogout?: () => void;
}

export function Navigation({ 
  currentPage, 
  onPageChange, 
  isAuthenticated = false, 
  userWallet = null,
  onLogout
}: NavigationProps) {
  const navItems = [
    { id: 'landing', label: 'Home', icon: Home, public: true },
    { id: 'properties', label: 'Land Parcels', icon: Building2, public: true },
    { id: 'marketplace', label: 'Marketplace', icon: ShoppingCart, public: false },
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3, public: false },
    { id: 'admin', label: 'Admin', icon: Settings, public: false },
  ];

  const handleAuthAction = () => {
    if (isAuthenticated) {
      onLogout?.();
    } else {
      onPageChange('auth');
    }
  };

  const formatWalletAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  return (
    <nav className="bg-white border-b border-gray-200 px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-8">
          <button 
            onClick={() => onPageChange('landing')}
            className="flex items-center space-x-2 hover:opacity-80 transition-opacity"
          >
            <div className="w-8 h-8 flex items-center justify-center">
              <img src={deedifyLogo} alt="Deedify" className="w-8 h-8 object-contain" />
            </div>
            <span className="text-xl font-semibold text-gray-900">Deedify</span>
          </button>
          
          <div className="hidden md:flex space-x-6">
            {navItems.map((item) => {
              // Hide private items if not authenticated
              if (!item.public && !isAuthenticated) return null;
              
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => onPageChange(item.id)}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-md transition-colors ${
                    currentPage === item.id
                      ? 'bg-primary/10 text-primary'
                      : 'text-gray-600 hover:text-primary hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {isAuthenticated && userWallet ? (
            <>
              <div className="hidden md:flex items-center space-x-2 px-3 py-2 bg-gray-50 rounded-lg">
                <Wallet className="w-4 h-4 text-gray-600" />
                <span className="text-sm font-medium text-gray-900">
                  {formatWalletAddress(userWallet)}
                </span>
              </div>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="relative h-8 w-8 rounded-full">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-primary text-white">
                        <User className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuItem onClick={() => onPageChange('dashboard')}>
                    <BarChart3 className="mr-2 h-4 w-4" />
                    <span>Dashboard</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onPageChange('marketplace')}>
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    <span>NFT Marketplace</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onPageChange('admin')}>
                    <Settings className="mr-2 h-4 w-4" />
                    <span>List Land</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={onLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <>
              <Button 
                variant="outline" 
                onClick={handleAuthAction}
                className="hidden md:flex items-center space-x-2"
              >
                <Wallet className="w-4 h-4" />
                <span>Connect Wallet</span>
              </Button>
              <Button 
                onClick={() => onPageChange('auth')}
                className="bg-primary hover:bg-primary/90"
              >
                Sign In
              </Button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}