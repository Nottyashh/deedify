import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Upload, X, FileText, Check, Clock, AlertCircle, Building2, DollarSign, Users } from 'lucide-react';

interface PropertyListing {
  id: string;
  title: string;
  status: 'draft' | 'verification' | 'listed' | 'sold';
  uploadedAt: string;
  totalValue: number;
  fractionsSold: number;
  totalFractions: number;
}

export function AdminPanel() {
  const [formData, setFormData] = useState({
    title: '',
    city: '',
    area: '',
    marketPrice: '',
    description: '',
    propertyType: '',
    totalFractions: 4000,
    pricePerFraction: ''
  });

  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [dragActive, setDragActive] = useState(false);

  const myListings: PropertyListing[] = [
    {
      id: '1',
      title: 'Plot A-17, Mumbai',
      status: 'listed',
      uploadedAt: '2024-01-15',
      totalValue: 5000000,
      fractionsSold: 2800,
      totalFractions: 4000
    },
    {
      id: '2',
      title: 'Skyline Apartments',
      status: 'sold',
      uploadedAt: '2023-12-20',
      totalValue: 3500000,
      fractionsSold: 4000,
      totalFractions: 4000
    },
    {
      id: '3',
      title: 'Prime Office Complex',
      status: 'verification',
      uploadedAt: '2024-01-20',
      totalValue: 8400000,
      fractionsSold: 0,
      totalFractions: 4000
    }
  ];

  const stats = {
    totalListings: 3,
    totalValue: 16900000,
    totalEarnings: 847500,
    activeFractions: 10800
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const newFiles = Array.from(e.dataTransfer.files);
      setUploadedFiles(prev => [...prev, ...newFiles]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setUploadedFiles(prev => [...prev, ...newFiles]);
    }
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock submission logic
    alert('Property submitted for verification!');
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'draft':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'verification':
        return <AlertCircle className="w-4 h-4 text-blue-500" />;
      case 'listed':
        return <Check className="w-4 h-4 text-green-500" />;
      case 'sold':
        return <Check className="w-4 h-4 text-gray-500" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft':
        return 'bg-yellow-100 text-yellow-800';
      case 'verification':
        return 'bg-blue-100 text-blue-800';
      case 'listed':
        return 'bg-green-100 text-green-800';
      case 'sold':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Property Owner Dashboard</h1>
          <p className="text-gray-600 mt-1">Manage your property listings and track performance</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Listings</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalListings}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Value</p>
                  <p className="text-2xl font-bold text-gray-900">₹{(stats.totalValue / 10000000).toFixed(1)}Cr</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Earnings</p>
                  <p className="text-2xl font-bold text-gray-900">₹{(stats.totalEarnings / 100000).toFixed(1)}L</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Fractions</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.activeFractions.toLocaleString()}</p>
                </div>
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-yellow-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="add-property" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="add-property">Add New Property</TabsTrigger>
            <TabsTrigger value="my-listings">My Listings</TabsTrigger>
          </TabsList>

          <TabsContent value="add-property" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Property Details Form */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Property Details</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="title">Property Title</Label>
                          <Input
                            id="title"
                            value={formData.title}
                            onChange={(e) => setFormData({...formData, title: e.target.value})}
                            placeholder="e.g., Plot A-17, Mumbai"
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="city">City</Label>
                          <Input
                            id="city"
                            value={formData.city}
                            onChange={(e) => setFormData({...formData, city: e.target.value})}
                            placeholder="e.g., Mumbai"
                            required
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="area">Total Area</Label>
                          <Input
                            id="area"
                            value={formData.area}
                            onChange={(e) => setFormData({...formData, area: e.target.value})}
                            placeholder="e.g., 2,500 sq ft"
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="propertyType">Property Type</Label>
                          <Select value={formData.propertyType} onValueChange={(value) => setFormData({...formData, propertyType: value})}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="residential">Residential</SelectItem>
                              <SelectItem value="commercial">Commercial</SelectItem>
                              <SelectItem value="mixed">Mixed Use</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="marketPrice">Market Price (₹)</Label>
                          <Input
                            id="marketPrice"
                            type="number"
                            value={formData.marketPrice}
                            onChange={(e) => setFormData({...formData, marketPrice: e.target.value})}
                            placeholder="e.g., 5000000"
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="totalFractions">Total Fractions</Label>
                          <Input
                            id="totalFractions"
                            type="number"
                            value={formData.totalFractions}
                            onChange={(e) => setFormData({...formData, totalFractions: parseInt(e.target.value) || 4000})}
                            required
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="description">Description</Label>
                        <Textarea
                          id="description"
                          value={formData.description}
                          onChange={(e) => setFormData({...formData, description: e.target.value})}
                          placeholder="Describe your property's key features and location advantages..."
                          rows={4}
                          required
                        />
                      </div>
                    </form>
                  </CardContent>
                </Card>

                {/* Document Upload */}
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Upload Documents</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div
                      className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                        dragActive ? 'border-primary bg-primary/5' : 'border-gray-300'
                      }`}
                      onDragEnter={handleDrag}
                      onDragLeave={handleDrag}
                      onDragOver={handleDrag}
                      onDrop={handleDrop}
                    >
                      <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <div className="space-y-2">
                        <p className="text-lg">Drag and drop files here</p>
                        <p className="text-gray-600">or</p>
                        <div>
                          <input
                            type="file"
                            multiple
                            onChange={handleFileInput}
                            className="hidden"
                            id="file-upload"
                            accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                          />
                          <label htmlFor="file-upload">
                            <Button variant="outline" type="button" asChild>
                              <span>Choose Files</span>
                            </Button>
                          </label>
                        </div>
                        <p className="text-sm text-gray-500">
                          Upload property documents (PDF, DOC, JPG, PNG - Max 10MB each)
                        </p>
                      </div>
                    </div>

                    {/* Uploaded Files */}
                    {uploadedFiles.length > 0 && (
                      <div className="mt-6 space-y-3">
                        <h4 className="font-medium">Uploaded Files</h4>
                        {uploadedFiles.map((file, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div className="flex items-center space-x-3">
                              <FileText className="w-5 h-5 text-gray-500" />
                              <div>
                                <div className="font-medium">{file.name}</div>
                                <div className="text-sm text-gray-600">
                                  {(file.size / 1024 / 1024).toFixed(2)} MB
                                </div>
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeFile(index)}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Submission Panel */}
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>Fractionalization & Minting</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="text-center p-6 bg-gray-50 rounded-lg">
                      <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Building2 className="w-8 h-8 text-primary" />
                      </div>
                      <h3 className="font-semibold mb-2">Ready to Tokenize?</h3>
                      <p className="text-sm text-gray-600 mb-4">
                        Your property will be fractionalized into {formData.totalFractions} NFT tokens
                      </p>
                      
                      {formData.marketPrice && (
                        <div className="text-sm space-y-1 mb-4">
                          <div>Price per fraction: ₹{Math.round(parseInt(formData.marketPrice) / formData.totalFractions).toLocaleString()}</div>
                          <div className="text-gray-600">Platform fee: 2.5%</div>
                        </div>
                      )}
                    </div>

                    <Button 
                      className="w-full bg-primary hover:bg-primary/90"
                      onClick={handleSubmit}
                      disabled={!formData.title || !formData.marketPrice || uploadedFiles.length === 0}
                    >
                      Fractionalize & Mint NFT
                    </Button>

                    <div className="text-xs text-gray-500 space-y-1">
                      <p>• Property will go through verification process</p>
                      <p>• NFTs minted on Solana blockchain</p>
                      <p>• Listing goes live after verification</p>
                    </div>
                  </CardContent>
                </Card>

                {/* Status Tracker */}
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Listing Process</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                          <Check className="w-4 h-4 text-green-600" />
                        </div>
                        <div>
                          <div className="font-medium">Property Details</div>
                          <div className="text-sm text-gray-600">Complete form</div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                          <span className="text-sm text-gray-600">2</span>
                        </div>
                        <div>
                          <div className="font-medium text-gray-400">Verification</div>
                          <div className="text-sm text-gray-400">Document review (2-3 days)</div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                          <span className="text-sm text-gray-600">3</span>
                        </div>
                        <div>
                          <div className="font-medium text-gray-400">Listed</div>
                          <div className="text-sm text-gray-400">Live for investors</div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                          <span className="text-sm text-gray-600">4</span>
                        </div>
                        <div>
                          <div className="font-medium text-gray-400">Sold</div>
                          <div className="text-sm text-gray-400">Fractions purchased</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="my-listings">
            <Card>
              <CardHeader>
                <CardTitle>My Property Listings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {myListings.map((listing) => (
                    <div key={listing.id} className="border rounded-lg p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-semibold">{listing.title}</h3>
                          <p className="text-gray-600">Listed on {listing.uploadedAt}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          {getStatusIcon(listing.status)}
                          <Badge className={getStatusColor(listing.status)}>
                            {listing.status.charAt(0).toUpperCase() + listing.status.slice(1)}
                          </Badge>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                        <div>
                          <div className="text-sm text-gray-600">Total Value</div>
                          <div className="font-semibold">₹{(listing.totalValue / 10000000).toFixed(1)}Cr</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-600">Fractions Sold</div>
                          <div className="font-semibold">{listing.fractionsSold}/{listing.totalFractions}</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-600">Progress</div>
                          <div className="font-semibold">{Math.round((listing.fractionsSold / listing.totalFractions) * 100)}%</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-600">Earnings</div>
                          <div className="font-semibold">₹{((listing.fractionsSold / listing.totalFractions) * listing.totalValue * 0.05).toLocaleString()}</div>
                        </div>
                      </div>

                      <div className="mb-4">
                        <Progress value={(listing.fractionsSold / listing.totalFractions) * 100} className="h-2" />
                      </div>

                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">View Details</Button>
                        {listing.status === 'listed' && (
                          <Button variant="outline" size="sm">Edit Listing</Button>
                        )}
                        <Button variant="outline" size="sm">Download Report</Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}