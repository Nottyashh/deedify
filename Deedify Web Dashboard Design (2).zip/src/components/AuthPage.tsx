import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Separator } from './ui/separator';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Building2, Mail, Phone, Shield, Wallet, Eye, EyeOff, Chrome } from 'lucide-react';
import deedifyLogo from 'figma:asset/55cb4fe518147b5b4d46a2dab11129d320de14d0.png';

interface AuthPageProps {
  onLogin: () => void;
  onBack: () => void;
}

export function AuthPage({ onLogin, onBack }: AuthPageProps) {
  const [authStep, setAuthStep] = useState<'login' | '2fa'>('login');
  const [loginMethod, setLoginMethod] = useState<'email' | 'wallet'>('email');
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    otp: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleEmailLogin = () => {
    // Simulate email login - in real app, this would validate credentials
    setAuthStep('2fa');
  };

  const handleWalletConnect = () => {
    // Simulate wallet connection - in real app, this would open wallet modal
    onLogin();
  };

  const handle2FAVerify = () => {
    // Simulate 2FA verification
    onLogin();
  };

  const handleGoogleLogin = () => {
    // Simulate Google OAuth - in real app, this would redirect to Google
    onLogin();
  };

  if (authStep === '2fa') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          <Card className="shadow-2xl border-0">
            <CardHeader className="text-center space-y-4">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mx-auto">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl">Two-Factor Authentication</CardTitle>
              <p className="text-gray-600">
                We've sent a verification code to your email/phone
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="otp">Enter 6-digit code</Label>
                <Input
                  id="otp"
                  placeholder="000000"
                  value={formData.otp}
                  onChange={(e) => handleInputChange('otp', e.target.value)}
                  className="text-center text-2xl tracking-widest"
                  maxLength={6}
                />
              </div>

              <Button 
                onClick={handle2FAVerify}
                className="w-full bg-primary hover:bg-primary/90"
                disabled={formData.otp.length !== 6}
              >
                Verify & Continue
              </Button>

              <div className="text-center">
                <button 
                  onClick={() => setAuthStep('login')}
                  className="text-gray-600 hover:text-primary transition-colors"
                >
                  ← Back to login
                </button>
              </div>

              <div className="text-center text-sm text-gray-500">
                <p>Didn't receive the code?</p>
                <button className="text-primary hover:underline">
                  Resend code
                </button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white flex items-center justify-center p-6">
      <div className="w-full max-w-4xl grid lg:grid-cols-2 gap-8 items-center">
        {/* Left Side - Branding */}
        <div className="hidden lg:block space-y-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 flex items-center justify-center">
                <img src={deedifyLogo} alt="Deedify" className="w-10 h-10 object-contain" />
              </div>
              <span className="text-2xl font-semibold text-gray-900">Deedify</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900 leading-tight">
              Welcome to the Future of{' '}
              <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Real Estate Investment
              </span>
            </h1>
            <p className="text-xl text-gray-600">
              Own fractions of premium properties, backed by blockchain technology
            </p>
          </div>

          <div className="relative">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBhcGFydG1lbnQlMjBidWlsZGluZ3xlbnwxfHx8fDE3NTc5Mjk4ODB8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Modern apartment building"
              className="w-full h-80 object-cover rounded-2xl shadow-xl"
            />
          </div>
        </div>

        {/* Right Side - Auth Form */}
        <div className="w-full max-w-md mx-auto">
          <Card className="shadow-2xl border-0">
            <CardHeader className="text-center space-y-4">
              <div className="lg:hidden flex items-center justify-center space-x-2">
                <div className="w-8 h-8 flex items-center justify-center">
                  <img src={deedifyLogo} alt="Deedify" className="w-8 h-8 object-contain" />
                </div>
                <span className="text-xl font-semibold text-gray-900">Deedify</span>
              </div>
              <CardTitle className="text-2xl">Login to Your Account</CardTitle>
              <p className="text-gray-600">
                Choose your preferred login method
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Login Method Toggle */}
              <div className="grid grid-cols-2 gap-2 p-1 bg-gray-100 rounded-lg">
                <button
                  onClick={() => setLoginMethod('email')}
                  className={`flex items-center justify-center space-x-2 py-2 px-4 rounded-md transition-all ${
                    loginMethod === 'email'
                      ? 'bg-white shadow-sm text-primary'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Mail className="w-4 h-4" />
                  <span>Email</span>
                </button>
                <button
                  onClick={() => setLoginMethod('wallet')}
                  className={`flex items-center justify-center space-x-2 py-2 px-4 rounded-md transition-all ${
                    loginMethod === 'wallet'
                      ? 'bg-white shadow-sm text-primary'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Wallet className="w-4 h-4" />
                  <span>Wallet</span>
                </button>
              </div>

              {loginMethod === 'email' ? (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Enter your password"
                        value={formData.password}
                        onChange={(e) => handleInputChange('password', e.target.value)}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <Button 
                    onClick={handleEmailLogin}
                    className="w-full bg-primary hover:bg-primary/90"
                    disabled={!formData.email || !formData.password}
                  >
                    Continue with Email
                  </Button>

                  <Separator />

                  <Button
                    onClick={handleGoogleLogin}
                    variant="outline"
                    className="w-full"
                  >
                    <Chrome className="w-4 h-4 mr-2" />
                    Continue with Google
                  </Button>
                </div>
              ) : (
                <div className="space-y-4 text-center">
                  <div className="space-y-4">
                    <div className="w-20 h-20 bg-gradient-to-br from-purple-400 to-blue-500 rounded-2xl flex items-center justify-center mx-auto">
                      <Wallet className="w-10 h-10 text-white" />
                    </div>
                    <p className="text-gray-600">
                      Connect your Solana wallet to access your account
                    </p>
                  </div>

                  <div className="space-y-3">
                    <Button 
                      onClick={handleWalletConnect}
                      className="w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
                    >
                      Connect Phantom Wallet
                    </Button>
                    <Button 
                      onClick={handleWalletConnect}
                      variant="outline"
                      className="w-full"
                    >
                      Connect Backpack Wallet
                    </Button>
                  </div>

                  <p className="text-xs text-gray-500">
                    Don't have a wallet? 
                    <a href="#" className="text-primary hover:underline ml-1">
                      Get started here
                    </a>
                  </p>
                </div>
              )}

              <div className="text-center">
                <button 
                  onClick={onBack}
                  className="text-gray-600 hover:text-primary transition-colors"
                >
                  ← Back to home
                </button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}