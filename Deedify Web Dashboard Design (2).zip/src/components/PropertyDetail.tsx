import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ArrowLeft, MapPin, TrendingUp, FileText, Download, Wallet, CreditCard, Share2, Heart } from 'lucide-react';
import { Input } from './ui/input';
import { Label } from './ui/label';

interface PropertyDetailProps {
  propertyId: string;
  onBack: () => void;
  onPurchase?: (propertyId: string, fractions: number) => void;
}

export function PropertyDetail({ propertyId, onBack, onPurchase }: PropertyDetailProps) {
  const [selectedAmount, setSelectedAmount] = useState(5);
  const [paymentMethod, setPaymentMethod] = useState<'wallet' | 'fiat'>('wallet');

  // Comprehensive property data lookup based on propertyId
  const getPropertyData = (id: string) => {
    const propertyData: { [key: string]: any } = {
      '1': {
        id: '1',
        title: 'Agricultural Plot A-17, Maharashtra',
        location: 'Nashik District, Maharashtra',
        image: 'https://images.unsplash.com/photo-1586859821397-c81e4971ca82?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtbGFuZCUyMGFncmljdWx0dXJhbCUyMHBsb3R8ZW58MXx8fHwxNzU4MDMyOTc5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        pricePerFraction: 1250,
        totalValue: 5000000,
        aiValuation: { low: 4800000, mid: 5200000, high: 5600000 },
        fractionsAvailable: 1200,
        totalFractions: 4000,
        fractionsSold: 2800,
        expectedReturn: 14.2,
        propertyType: 'Agricultural',
        area: '25 acres',
        soilType: 'Black Cotton Soil',
        waterSource: 'Bore well + Canal irrigation',
        nearestTown: 'Nashik (12 km)',
        documents: [
          { name: 'Land Title Deed (7/12)', type: 'PDF', size: '2.1 MB' },
          { name: 'Soil Quality Report', type: 'PDF', size: '1.5 MB' },
          { name: 'Water Rights Certificate', type: 'PDF', size: '1.2 MB' },
          { name: 'Agricultural Survey Records', type: 'PDF', size: '980 KB' },
          { name: 'Revenue Records (8A)', type: 'PDF', size: '750 KB' }
        ],
        description: 'Premium agricultural land in Maharashtra\'s wine country. This fertile plot features rich black cotton soil ideal for grape cultivation and other cash crops. Located in the famous Nashik district with established irrigation infrastructure.',
        highlights: [
          'Located in Maharashtra wine belt',
          'Rich black cotton soil perfect for viticulture',
          'Dual irrigation: bore well + canal access',
          'Proximity to wine processing facilities',
          'Strong local farming community',
          'Government agricultural subsidies available'
        ],
        annualRentalYield: 9.2,
        capitalAppreciation: 5.0,
        cropSuitability: ['Grapes', 'Sugarcane', 'Cotton', 'Pomegranate']
      },
      '2': {
        id: '2',
        title: 'Commercial Land Parcel',
        location: 'Sector 89, Gurgaon, Haryana',
        image: 'https://images.unsplash.com/photo-1515102502805-e970df437805?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZ3JpY3VsdHVyYWwlMjBsYW5kJTIwcGxvdCUyMGFlcmlhbHxlbnwxfHx8fDE3NTgwMzI5ODJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        pricePerFraction: 875,
        totalValue: 3500000,
        aiValuation: { low: 3200000, mid: 3500000, high: 3800000 },
        fractionsAvailable: 800,
        totalFractions: 4000,
        fractionsSold: 3200,
        expectedReturn: 12.8,
        propertyType: 'Commercial',
        area: '5.2 acres',
        zoningType: 'Commercial Mixed Use',
        roadAccess: '60-foot wide main road',
        nearestMetro: 'Huda City Centre (3.5 km)',
        documents: [
          { name: 'Commercial Land Deed', type: 'PDF', size: '2.8 MB' },
          { name: 'Zoning Clearance Certificate', type: 'PDF', size: '1.9 MB' },
          { name: 'Environmental Clearance', type: 'PDF', size: '1.4 MB' },
          { name: 'Development Rights Document', type: 'PDF', size: '1.1 MB' },
          { name: 'Municipal Approval Letter', type: 'PDF', size: '820 KB' }
        ],
        description: 'Strategic commercial land parcel in rapidly developing Gurgaon sector. Prime location with excellent connectivity to Delhi-NCR. Approved for mixed-use development with high potential for appreciation.',
        highlights: [
          'Strategic location in New Gurgaon',
          'Metro connectivity within 4 km',
          'Approved for commercial development',
          'Surrounded by IT parks and malls',
          'High footfall commercial zone',
          'Government infrastructure development planned'
        ],
        annualRentalYield: 7.8,
        capitalAppreciation: 5.0,
        developmentPotential: ['Retail Complex', 'Office Spaces', 'Mixed-Use Development', 'Warehouse']
      },
      '3': {
        id: '3',
        title: 'Prime Agricultural Land',
        location: 'Ludhiana District, Punjab',
        image: 'https://images.unsplash.com/photo-1671699556172-d9d39527dae5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtJTIwZmllbGQlMjBncmVlbiUyMGxhbmR8ZW58MXx8fHwxNzU4MDMyOTg0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        pricePerFraction: 2100,
        totalValue: 8400000,
        aiValuation: { low: 8000000, mid: 8400000, high: 9200000 },
        fractionsAvailable: 600,
        totalFractions: 4000,
        fractionsSold: 3400,
        expectedReturn: 16.5,
        propertyType: 'Agricultural',
        area: '40 acres',
        soilType: 'Alluvial Soil',
        waterSource: 'Canal irrigation + Tube wells',
        nearestTown: 'Ludhiana (8 km)',
        documents: [
          { name: 'Punjab Land Records (Jamabandi)', type: 'PDF', size: '2.3 MB' },
          { name: 'Soil Fertility Assessment', type: 'PDF', size: '1.7 MB' },
          { name: 'Water Rights Certificate', type: 'PDF', size: '1.3 MB' },
          { name: 'Agricultural Income Records', type: 'PDF', size: '1.0 MB' },
          { name: 'Crop Insurance Documents', type: 'PDF', size: '890 KB' }
        ],
        description: 'Exceptional agricultural land in Punjab\'s most fertile region. Known for high-yield crop production with reliable irrigation from the Sutlej canal system. Part of India\'s wheat and rice bowl with proven track record.',
        highlights: [
          'Located in India\'s agricultural heartland',
          'Highly fertile alluvial soil',
          'Reliable canal + groundwater irrigation',
          'Established grain procurement system',
          'MSP (Minimum Support Price) guarantee',
          'Proximity to agricultural research institutes'
        ],
        annualRentalYield: 11.5,
        capitalAppreciation: 5.0,
        cropSuitability: ['Wheat', 'Rice', 'Maize', 'Sugarcane', 'Cotton']
      },
      '4': {
        id: '4',
        title: 'Organic Farm Plot B-23',
        location: 'Mysore District, Karnataka',
        image: 'https://images.unsplash.com/photo-1586859821397-c81e4971ca82?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtbGFuZCUyMGFncmljdWx0dXJhbCUyMHBsb3R8ZW58MXx8fHwxNzU4MDMyOTc5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        pricePerFraction: 1875,
        totalValue: 7500000,
        aiValuation: { low: 7200000, mid: 7500000, high: 7900000 },
        fractionsAvailable: 320,
        totalFractions: 4000,
        fractionsSold: 3680,
        expectedReturn: 13.7,
        propertyType: 'Agricultural',
        area: '18 acres',
        soilType: 'Red Laterite Soil',
        waterSource: 'Natural spring + Rainwater harvesting',
        nearestTown: 'Mysore (15 km)',
        documents: [
          { name: 'Organic Certification (NPOP)', type: 'PDF', size: '2.0 MB' },
          { name: 'Karnataka Land Records', type: 'PDF', size: '1.6 MB' },
          { name: 'Water Quality Test Report', type: 'PDF', size: '1.2 MB' },
          { name: 'Soil Health Card', type: 'PDF', size: '950 KB' },
          { name: 'Organic Farming License', type: 'PDF', size: '780 KB' }
        ],
        description: 'Certified organic farmland in Karnataka\'s spice growing region. Features natural water sources and chemical-free soil perfect for organic cultivation. Premium location for spice and coffee cultivation.',
        highlights: [
          'Certified organic by NPOP standards',
          'Natural spring water source',
          'Ideal climate for spice cultivation',
          'Chemical-free soil for 5+ years',
          'Proximity to spice processing units',
          'Premium organic produce market access'
        ],
        annualRentalYield: 8.7,
        capitalAppreciation: 5.0,
        cropSuitability: ['Cardamom', 'Black Pepper', 'Coffee', 'Arecanut', 'Vanilla']
      },
      '5': {
        id: '5',
        title: 'Industrial Land Zone',
        location: 'Medchal-Malkajgiri District, Hyderabad, Telangana',
        image: 'https://images.unsplash.com/photo-1515102502805-e970df437805?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZ3JpY3VsdHVyYWwlMjBsYW5kJTIwcGxvdCUyMGFlcmlhbHxlbnwxfHx8fDE3NTgwMzI5ODJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        pricePerFraction: 1500,
        totalValue: 6000000,
        aiValuation: { low: 5800000, mid: 6000000, high: 6400000 },
        fractionsAvailable: 950,
        totalFractions: 4000,
        fractionsSold: 3050,
        expectedReturn: 15.1,
        propertyType: 'Commercial',
        area: '8.5 acres',
        zoningType: 'Industrial Development',
        roadAccess: '80-foot highway frontage',
        nearestAirport: 'RGIA Hyderabad (25 km)',
        documents: [
          { name: 'Industrial Land Conversion Order', type: 'PDF', size: '2.5 MB' },
          { name: 'Environmental Impact Assessment', type: 'PDF', size: '2.1 MB' },
          { name: 'Telangana Revenue Records', type: 'PDF', size: '1.8 MB' },
          { name: 'Industrial Zone Approval', type: 'PDF', size: '1.4 MB' },
          { name: 'Utilities Connection Feasibility', type: 'PDF', size: '1.1 MB' }
        ],
        description: 'Strategic industrial land in Hyderabad\'s expanding pharmaceutical corridor. Part of designated industrial zone with excellent logistics connectivity. Ideal for manufacturing and warehousing operations.',
        highlights: [
          'Located in Genome Valley pharma hub',
          'Highway frontage for logistics',
          'Industrial zone with utilities',
          'Tax incentives for manufacturing',
          'Proximity to international airport',
          'Government industrial promotion schemes'
        ],
        annualRentalYield: 9.1,
        capitalAppreciation: 6.0,
        developmentPotential: ['Manufacturing Unit', 'Pharmaceutical Facility', 'Logistics Hub', 'Data Center']
      },
      '6': {
        id: '6',
        title: 'Coastal Agricultural Plot',
        location: 'Ratnagiri District, Konkan Coast, Maharashtra',
        image: 'https://images.unsplash.com/photo-1671699556172-d9d39527dae5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtJTIwZmllbGQlMjBncmVlbiUyMGxhbmR8ZW58MXx8fHwxNzU4MDMyOTg0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        pricePerFraction: 3200,
        totalValue: 12800000,
        aiValuation: { low: 12000000, mid: 12800000, high: 13500000 },
        fractionsAvailable: 450,
        totalFractions: 4000,
        fractionsSold: 3550,
        expectedReturn: 11.9,
        propertyType: 'Agricultural',
        area: '32 acres',
        soilType: 'Coastal Alluvium',
        waterSource: 'Monsoon + Groundwater',
        nearestTown: 'Ratnagiri (6 km)',
        documents: [
          { name: 'Coastal Zone Clearance', type: 'PDF', size: '2.4 MB' },
          { name: 'Maharashtra Land Records', type: 'PDF', size: '1.9 MB' },
          { name: 'Mango Plantation Survey', type: 'PDF', size: '1.5 MB' },
          { name: 'Soil Salinity Test Report', type: 'PDF', size: '1.2 MB' },
          { name: 'Coconut Board Registration', type: 'PDF', size: '890 KB' }
        ],
        description: 'Pristine coastal agricultural land famous for Alphonso mango cultivation. Located in the heart of Konkan\'s fruit belt with ideal climate for premium tropical fruits. Established plantation with mature trees.',
        highlights: [
          'Famous Alphonso mango growing region',
          'Established mature fruit trees',
          'Coastal climate ideal for tropical fruits',
          'Premium export quality produce',
          'Proximity to Mumbai markets',
          'Heritage plantation with 30+ year trees'
        ],
        annualRentalYield: 6.9,
        capitalAppreciation: 5.0,
        cropSuitability: ['Alphonso Mangoes', 'Coconut', 'Cashew', 'Jackfruit', 'Kokum']
      }
    };

    return propertyData[id] || propertyData['1']; // Fallback to first property
  };

  const property = getPropertyData(propertyId);
  const soldPercentage = (property.fractionsSold / property.totalFractions) * 100;

  const handleInvestment = () => {
    // Mock investment logic
    if (onPurchase) {
      onPurchase(propertyId, selectedAmount);
    }
    alert(`Investment of ${selectedAmount} fractions (₹${selectedAmount * property.pricePerFraction}) initiated!`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <Button variant="ghost" onClick={onBack} className="mb-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Properties
          </Button>
          
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">{property.title}</h1>
              <div className="flex items-center text-gray-600 mt-2">
                <MapPin className="w-4 h-4 mr-1" />
                {property.location}
              </div>
            </div>
            
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">
                <Heart className="w-4 h-4 mr-2" />
                Save
              </Button>
              <Button variant="outline" size="sm">
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Property Image */}
            <div className="relative">
              <ImageWithFallback
                src={property.image}
                alt={property.title}
                className="w-full h-96 object-cover rounded-lg"
              />
              <Badge className="absolute top-4 left-4 bg-primary text-white">
                {property.propertyType}
              </Badge>
            </div>

            {/* Tabs */}
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="documents">Documents</TabsTrigger>
                <TabsTrigger value="valuation">Valuation</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Property Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-700">{property.description}</p>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <div className="text-sm text-gray-600">Total Value</div>
                        <div className="font-semibold">₹{(property.totalValue / 10000000).toFixed(1)}Cr</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-600">Area</div>
                        <div className="font-semibold">{property.area}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-600">{property.propertyType === 'Agricultural' ? 'Soil Type' : 'Zoning'}</div>
                        <div className="font-semibold">{property.propertyType === 'Agricultural' ? property.soilType : property.zoningType}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-600">Expected Return</div>
                        <div className="font-semibold text-green-600">{property.expectedReturn}%</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-gray-600">Water Source</div>
                        <div className="font-semibold">{property.waterSource}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-600">{property.propertyType === 'Agricultural' ? 'Nearest Town' : property.nearestMetro ? 'Nearest Metro' : 'Nearest Airport'}</div>
                        <div className="font-semibold">{property.nearestTown || property.nearestMetro || property.nearestAirport}</div>
                      </div>
                    </div>

                    {/* Show crop suitability for agricultural land or development potential for commercial */}
                    {property.propertyType === 'Agricultural' && property.cropSuitability && (
                      <div>
                        <h4 className="font-semibold mb-2">Suitable Crops</h4>
                        <div className="flex flex-wrap gap-2">
                          {property.cropSuitability.map((crop: string, index: number) => (
                            <Badge key={index} variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              {crop}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {property.propertyType === 'Commercial' && property.developmentPotential && (
                      <div>
                        <h4 className="font-semibold mb-2">Development Potential</h4>
                        <div className="flex flex-wrap gap-2">
                          {property.developmentPotential.map((potential: string, index: number) => (
                            <Badge key={index} variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                              {potential}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    <div>
                      <h4 className="font-semibold mb-2">Key Highlights</h4>
                      <ul className="space-y-1">
                        {property.highlights.map((highlight, index) => (
                          <li key={index} className="flex items-center text-gray-700">
                            <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                            {highlight}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="documents" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Property Documents</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {property.documents.map((doc, index) => (
                        <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                              <FileText className="w-5 h-5 text-red-600" />
                            </div>
                            <div>
                              <div className="font-medium">{doc.name}</div>
                              <div className="text-sm text-gray-600">{doc.type} • {doc.size}</div>
                            </div>
                          </div>
                          <Button variant="outline" size="sm">
                            <Download className="w-4 h-4 mr-2" />
                            Download
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="valuation" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <TrendingUp className="w-5 h-5 mr-2 text-green-500" />
                      AI Valuation Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-primary mb-2">
                        ₹{(property.aiValuation.mid / 10000000).toFixed(1)}Cr
                      </div>
                      <div className="text-gray-600">Current AI Valuation</div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Conservative</span>
                        <span className="font-semibold">₹{(property.aiValuation.low / 10000000).toFixed(1)}Cr</span>
                      </div>
                      <Progress value={85} className="h-2" />
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Market Value</span>
                        <span className="font-semibold text-primary">₹{(property.aiValuation.mid / 10000000).toFixed(1)}Cr</span>
                      </div>
                      <Progress value={100} className="h-2" />
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Optimistic</span>
                        <span className="font-semibold">₹{(property.aiValuation.high / 10000000).toFixed(1)}Cr</span>
                      </div>
                      <Progress value={75} className="h-2" />
                    </div>

                    <div className="bg-blue-50 rounded-lg p-4">
                      <div className="text-sm text-blue-800">
                        <strong>Valuation Factors:</strong> Location premium, soil quality analysis, 
                        water availability, market accessibility, crop yield potential, and comparable land sales data.
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Investment Panel */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Investment Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-600">Ownership Progress</span>
                    <span className="text-sm font-medium">{soldPercentage.toFixed(1)}% sold</span>
                  </div>
                  <Progress value={soldPercentage} className="h-3" />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>{property.fractionsSold} sold</span>
                    <span>{property.fractionsAvailable} available</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-gray-600">Price per Fraction</div>
                    <div className="text-lg font-bold">₹{property.pricePerFraction.toLocaleString()}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600">Min. Investment</div>
                    <div className="text-lg font-bold">₹{property.pricePerFraction.toLocaleString()}</div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="amount">Number of Fractions</Label>
                    <Input
                      id="amount"
                      type="number"
                      value={selectedAmount}
                      onChange={(e) => setSelectedAmount(parseInt(e.target.value) || 1)}
                      min="1"
                      max={property.fractionsAvailable}
                      className="mt-1"
                    />
                    <div className="text-sm text-gray-600 mt-1">
                      Total: ₹{(selectedAmount * property.pricePerFraction).toLocaleString()}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant={paymentMethod === 'wallet' ? 'default' : 'outline'}
                      onClick={() => setPaymentMethod('wallet')}
                      className="w-full"
                    >
                      <Wallet className="w-4 h-4 mr-2" />
                      USDC
                    </Button>
                    <Button
                      variant={paymentMethod === 'fiat' ? 'default' : 'outline'}
                      onClick={() => setPaymentMethod('fiat')}
                      className="w-full"
                    >
                      <CreditCard className="w-4 h-4 mr-2" />
                      INR
                    </Button>
                  </div>

                  {paymentMethod === 'wallet' ? (
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button className="w-full bg-primary hover:bg-primary/90 text-lg py-6">
                          Buy with Wallet (USDC)
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Connect Solana Wallet</DialogTitle>
                          <DialogDescription>
                            Choose your preferred Solana wallet to complete the investment transaction.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <p className="text-gray-600">
                            Connect your Solana wallet to complete the investment.
                          </p>
                          <div className="space-y-2">
                            <Button className="w-full" variant="outline">
                              Phantom Wallet
                            </Button>
                            <Button className="w-full" variant="outline">
                              Solflare Wallet
                            </Button>
                            <Button className="w-full" variant="outline">
                              Other Wallets
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  ) : (
                    <Button 
                      className="w-full bg-secondary hover:bg-secondary/90 text-lg py-6"
                      onClick={handleInvestment}
                    >
                      Buy with INR (Fiat)
                    </Button>
                  )}
                </div>

                <div className="text-xs text-gray-500 space-y-1">
                  <p>• NFT ownership certificate will be minted upon purchase</p>
                  <p>• Rental income distributed quarterly</p>
                  <p>• Fractions can be traded on secondary market</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Expected Returns</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Annual Rental Yield</span>
                    <span className="font-semibold">{property.annualRentalYield}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Capital Appreciation</span>
                    <span className="font-semibold">{property.capitalAppreciation}%</span>
                  </div>
                  <div className="border-t pt-3">
                    <div className="flex justify-between">
                      <span className="font-medium">Total Expected Return</span>
                      <span className="font-bold text-green-600">{property.expectedReturn}%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}