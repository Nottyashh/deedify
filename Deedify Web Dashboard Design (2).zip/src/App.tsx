import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { LandingPage } from './components/LandingPage';
import { AuthPage } from './components/AuthPage';
import { PropertyListings } from './components/PropertyListings';
import { PropertyDetail } from './components/PropertyDetail';
import { Dashboard } from './components/Dashboard';
import { AdminPanel } from './components/AdminPanel';
import { NFTMarketplace } from './components/NFTMarketplace';

export default function App() {
  const [currentPage, setCurrentPage] = useState('landing');
  const [selectedPropertyId, setSelectedPropertyId] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userWallet, setUserWallet] = useState<string | null>(null);
  const [userHoldings, setUserHoldings] = useState<{ [propertyId: string]: number }>({
    '1': 12, // User already owns 12 fractions of property 1
    '2': 8,  // User already owns 8 fractions of property 2  
    '3': 15  // User already owns 15 fractions of property 3
  });

  const handlePropertyPurchase = (propertyId: string, fractions: number) => {
    setUserHoldings(prev => ({
      ...prev,
      [propertyId]: (prev[propertyId] || 0) + fractions
    }));
    // Redirect to dashboard after purchase to see voting rights
    setCurrentPage('dashboard');
  };

  const handlePageChange = (page: string) => {
    // Redirect to auth if trying to access protected pages
    if (!isAuthenticated && ['dashboard', 'admin', 'marketplace'].includes(page)) {
      setCurrentPage('auth');
      return;
    }
    
    setCurrentPage(page);
    setSelectedPropertyId(null);
  };

  const handlePropertySelect = (propertyId: string) => {
    setSelectedPropertyId(propertyId);
    setCurrentPage('property-detail');
  };

  const handleBackToProperties = () => {
    setCurrentPage('properties');
    setSelectedPropertyId(null);
  };

  const handleLogin = () => {
    setIsAuthenticated(true);
    setUserWallet('0x1234...5678'); // Mock wallet address
    setCurrentPage('dashboard'); // Redirect to dashboard after login
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUserWallet(null);
    setCurrentPage('landing');
  };

  const handleBackToLanding = () => {
    setCurrentPage('landing');
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'landing':
        return <LandingPage onPageChange={handlePageChange} />;
      case 'auth':
        return <AuthPage onLogin={handleLogin} onBack={handleBackToLanding} />;
      case 'properties':
        return <PropertyListings onPropertySelect={handlePropertySelect} />;
      case 'property-detail':
        return selectedPropertyId ? (
          <PropertyDetail 
            propertyId={selectedPropertyId} 
            onBack={handleBackToProperties}
            onPurchase={handlePropertyPurchase}
          />
        ) : (
          <PropertyListings onPropertySelect={handlePropertySelect} />
        );
      case 'dashboard':
        return <Dashboard userHoldings={userHoldings} />;
      case 'admin':
        return <AdminPanel />;
      case 'marketplace':
        return <NFTMarketplace userAddress={userWallet} />;
      default:
        return <LandingPage onPageChange={handlePageChange} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {currentPage !== 'auth' && (
        <Navigation 
          currentPage={currentPage} 
          onPageChange={handlePageChange}
          isAuthenticated={isAuthenticated}
          userWallet={userWallet}
          onLogout={handleLogout}
        />
      )}
      <main>
        {renderCurrentPage()}
      </main>
    </div>
  );
}