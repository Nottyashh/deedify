
  # Deedify Web Dashboard Design

  This is a code bundle for Deedify Web Dashboard Design. The original project is available at https://www.figma.com/design/Xgj4iXGu5C7D9AQ4hEDO2T/Deedify-Web-Dashboard-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  